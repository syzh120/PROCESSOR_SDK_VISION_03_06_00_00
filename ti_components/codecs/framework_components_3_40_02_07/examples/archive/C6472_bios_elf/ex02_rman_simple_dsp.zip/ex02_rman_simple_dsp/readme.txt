To build this example:

1. Set up the environment variables in products.mak

2. Build the example by running:

       gmake clean
       gmake
