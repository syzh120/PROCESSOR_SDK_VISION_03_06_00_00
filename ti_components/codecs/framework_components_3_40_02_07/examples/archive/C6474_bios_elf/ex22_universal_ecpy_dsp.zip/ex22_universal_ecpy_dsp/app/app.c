/*
 * Copyright (c) 2012-2013, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
/*
 *  ======== app.c ========
 */

#include <xdc/std.h>
#include <xdc/runtime/Assert.h>
#include <xdc/runtime/Diags.h>
#include <xdc/runtime/Log.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/knl/SemThread.h>

#include <stdio.h>
#include <stdlib.h>

#include <ti/sdo/fc/rman/rman.h>
#include <ti/sdo/fc/dskt2/dskt2.h>
#include <ti/sdo/fc/memutils/memutils.h>
#include <ti/sysbios/knl/Task.h>

/* Algorithm */
#include <universal_dma_ti.h>

/* xdm */
#include <ti/xdais/dm/iuniversal.h>

/* FC resource manager */
#include <ti/sdo/fc/ires/edma3chan/iresman_edma3Chan.h>

#ifdef xdc_target__isaCompatible_64P
extern __cregister volatile Uns DNUM;
#endif

/* EDMA3 module can be configured at runtime if required */
/* For that you will need to include this configuration file */
#include <ti/sdo/fc/edma3/edma3_config.h>


/* Placing the DMA buffers in INTERNAL/EXTERNAL memory as desired */
/* A single image of the exe will be built for each core,
   Each core will have it's own SRCBUFF in internal memory */
#pragma DATA_SECTION(SRCBUFF,".INT_HEAP")

#pragma DATA_SECTION(DSTBUFF,".EXT_HEAP")


/*
 *  ======== ScratchTskAttrs ========
 */
typedef struct ScratchTskAttr {
    Int         priority;       /* Priority of task */
    Int         scratchId;      /* Scratch group in which to create the task */
    Int         yieldFlag;
    Uns         fillValue;
} ScratchTskAttrs;


#define MOD_NAME "*"
#define DMAXFER_BUFSIZE 0x100
#define NUMTASKS 1 /* 12 */
#define MAXTASKS 12
#define MAXCORES 16

#define CURTRACE ti_sdo_fc_rman_examples_dmaXferScratch

/* If you need to override the default configuration for edma resource
   assignment to regions, you will need to declare a structure initialized
   with the new assignments, and then assign it to EDMA3_PARAMS.regionConfig.

    #include <ti/sdo/fc/edma3/edma3_config.h>
    extern EDMA3_InstanceInitConfig overridingConfig[][8];
*/

unsigned int SRCBUFF[DMAXFER_BUFSIZE * NUMTASKS * MAXCORES];
unsigned int DSTBUFF[DMAXFER_BUFSIZE * NUMTASKS * MAXCORES];

/*
 * heapId in which to create the tasks
 */
extern Int EXT_HEAP;
extern Int INT_HEAP;

/* Semaphores for the tasks */
static SemThread_Handle done = NULL;  /* Gets posted by last task to finish */

/* Protect DSKT2_createAlg and DSKT2_freeAlg */
static SemThread_Handle mutex = NULL;

/* Scratch task parameters */
static ScratchTskAttrs attrsTable[MAXTASKS] = {
    /* priority,    scratchGroup   yieldFlag somAttr */
    12,              1,      1,     0x1,
    13,              1,      0,     0x2,
        13,              1,      0,     0x3,
        13,              1,      0,     0x4,
        13,              1,      0,     0x5,
        13,              1,      0,     0x6,
        13,              1,      0,     0x7,
    12,              1,      1,     0x8,
        13,              1,      0,     0x9,
    12,              1,      1,     0xA,
        13,              1,      0,     0xB,
    12,              1,      1,     0xC
};

/*
 * extern declaration
 */
extern Int smain(Int argc, Char * argv[]);
extern Int rmanTask(UArg arg0, UArg arg1);

/*
 *  ======== smain ========
 */
/* ARGSUSED */
Int smain(Int argc, Char * argv[])
{
    SemThread_Params semParams;
    Task_Params      taskParams;
    Task_Handle      tsk;
    Int              i;
#ifdef xdc_target__isaCompatible_64P
    Int coreId = DNUM;
#else
    Int coreId =0 ;
#endif
    IRES_Status status;
    IRESMAN_Edma3ChanParams initArgs;

    status = RMAN_init();

   if (IRES_OK != status) {
        Log_print0(Diags_USER7, "[+7] main> RMAN initialization Failed ");
        System_abort("Aborting...\n");
    }

    initArgs.baseConfig.size = sizeof(IRESMAN_Edma3ChanParams);
    initArgs.baseConfig.allocFxn = &DSKT2_allocPersistent;
    initArgs.baseConfig.freeFxn = &DSKT2_freePersistent;

    status = RMAN_register(&IRESMAN_EDMA3CHAN, (IRESMAN_Params *)&initArgs);

   if ((IRES_OK != status) && ( IRES_EEXISTS != status)){
        Log_print0(Diags_USER7, "[+7] main> IRES registration Failed ");
        System_abort("Aborting...\n");
    }



    /* If you'd like to override the default configuration for one/more
       cores, do it as follows
       EDMA3_PARAMS.regionConfig = overridingConfig[0][coreId];
    */

    /* If you'd like to use the existing default configuration for one/more
       cores, then associate each core with a different region on potentially
       different EDMA3 physical hardware instances
       EDMA3_PARAMS.regionId = m;
       ti_sdo_fc_edma3_EDMA3_physicalId = n;
    */



    /* Populate SRCBUF, and DSTBUF with data */

    for (i = 0; i < (DMAXFER_BUFSIZE * NUMTASKS); i++) {
        SRCBUFF[i + coreId * DMAXFER_BUFSIZE * NUMTASKS] = 0x8C0FFEE0 | coreId;
        DSTBUFF[i + coreId * DMAXFER_BUFSIZE * NUMTASKS] = 0xDEADBEE0 | coreId;
    }

    MEMUTILS_cacheWb(&SRCBUFF[coreId * DMAXFER_BUFSIZE * NUMTASKS],
            DMAXFER_BUFSIZE * NUMTASKS * 4);
    MEMUTILS_cacheWb(&DSTBUFF[coreId * DMAXFER_BUFSIZE * NUMTASKS],
            DMAXFER_BUFSIZE * NUMTASKS * 4);

    SemThread_Params_init(&semParams);
    done = SemThread_create(0, &semParams, NULL);

    SemThread_Params_init(&semParams);
    mutex = SemThread_create(1, &semParams, NULL);

    if ((done == NULL) || (mutex == NULL)) {
        Log_print0(Diags_USER7, "[+7] smain> Semaphore creation failed");

        System_abort("SemThread_create failed\n");
    }

    Task_Params_init(&taskParams);

    for (i = 0; i < NUMTASKS; i++) {
        Task_Params_init(&taskParams);
        taskParams.priority = attrsTable[i].priority;
        taskParams.stackSize = 0x8000;

/* For the multicore builds, we take care to keep everything in internal
   memory since external memory is shared.*/
        taskParams.stackHeap = (IHeap_Handle)INT_HEAP;
        taskParams.arg0 = i + 1; /* task id */
        taskParams.arg1 = i;     /* index into attrsTable */
        tsk = Task_create((Task_FuncPtr)rmanTask, &taskParams, NULL);

        if (tsk == NULL) {

            Log_print1(Diags_USER7, "[+7] smain> Task_create of task %d failed",
                    (IArg)(i + 1));

            System_abort("Task_create() failed\n");
        }
    }

    for (i = 0; i < NUMTASKS; i++) {
        SemThread_pend(done, SemThread_FOREVER, NULL);
    }

    MEMUTILS_cacheInv(DSTBUFF, DMAXFER_BUFSIZE * NUMTASKS * 4);
    for (i = 0; i < (DMAXFER_BUFSIZE * NUMTASKS); i++) {
        if (SRCBUFF[i + coreId * DMAXFER_BUFSIZE * NUMTASKS] !=
                DSTBUFF[i + coreId * DMAXFER_BUFSIZE * NUMTASKS]) {
            printf("*** Address mismatch at index %d, 0x%x != 0x%x\n",
                    i, SRCBUFF[i + coreId * DMAXFER_BUFSIZE * NUMTASKS] ,
                    DSTBUFF[i + coreId * DMAXFER_BUFSIZE * NUMTASKS]);
            System_abort(" smain> EXAMPLE FAILED******");
        }
    }


    SemThread_delete(&mutex);
    SemThread_delete(&done);

    Log_print0(Diags_USER4, "[+4] smain> EXAMPLE FINISHED");
    printf(" smain> EXAMPLE FINISHED\n");

    return (0);
}
void Log_printr0(int i, char *s){}
/*
 *  ======== rmanTask ========
 */
/* ARGSUSED */
Int rmanTask(UArg taskId, UArg index)
{
#ifdef xdc_target__isaCompatible_64P
    Int coreId = DNUM;
#else
    Int coreId =0 ;
#endif
    Int         scratchId;
    IALG_Fxns * algFxns = (IALG_Fxns *)&UNIVERSAL_DMA_TI_CODECIRES;
    IRES_Fxns * resFxns = &UNIVERSAL_DMA_TI_IRES;
    IUNIVERSAL_Handle alg = NULL;
    IRES_Status status;

    XDM1_BufDesc                inBufDesc;
    XDM1_BufDesc                outBufDesc;
    XDM1_BufDesc                inOutBufDesc;
    XDAS_Int8 *                 buffSrc;
    XDAS_Int8 *                 buffDest;

    UNIVERSAL_DMA_InArgs        decInArgs;
    IUNIVERSAL_OutArgs          decOutArgs;

    inBufDesc.numBufs = outBufDesc.numBufs = 1;
    inOutBufDesc.numBufs = 0;
    inBufDesc.descs[0].bufSize = outBufDesc.descs[0].bufSize = DMAXFER_BUFSIZE;
    decInArgs.numBytes = DMAXFER_BUFSIZE * 4;
    buffSrc = (XDAS_Int8 *)&SRCBUFF[(coreId * NUMTASKS + index) *
            DMAXFER_BUFSIZE];
    buffDest = (XDAS_Int8 *)&DSTBUFF[(coreId * NUMTASKS + index) *
            DMAXFER_BUFSIZE];

    /* For multicore platforms, peripherals such as the the EDMA hardware do not
       recognize internal memory addresses (generated by the platform), these
       addresses have to be convered into h/w specific addresses that DMA
       understands. */
    inBufDesc.descs[0].buf = MEMUTILS_getPhysicalAddr(buffSrc);
    outBufDesc.descs[0].buf = MEMUTILS_getPhysicalAddr(buffDest);

    /* initialize all "sized" fields */
    decInArgs.size    = sizeof(decInArgs);
    decOutArgs.size   = sizeof(decOutArgs);

    scratchId = attrsTable[index].scratchId;

    SemThread_pend(mutex, SemThread_FOREVER, NULL);

    /* Create an instance of the algorithm using "algFxns" */
    alg = (IUNIVERSAL_Handle)DSKT2_createAlg(scratchId,
            (IALG_Fxns *)algFxns, NULL,(IALG_Params *)NULL);
    if (alg == NULL) {
        System_printf("Alg creation failed for alg\n");
        return (-1);
    }

    SemThread_post(mutex, NULL);

    /* Assign resources to the algorithm */
    status = RMAN_assignResources((IALG_Handle)alg, resFxns, scratchId);
    if (status != IRES_OK) {
        System_printf("Assign Resource Failed [%d]\n", status);
        return (-1);
    }

    /*
     * Activate the Algorithm
     */
    DSKT2_activateAlg(scratchId, (IALG_Handle)alg);

    /*
     * Activate All Resources
     */
    RMAN_activateAllResources((IALG_Handle)alg, resFxns, scratchId);

    /*
     * Use IALG interfaces to call the process API that performs the DMA
     * transfer.
     */
    if (IUNIVERSAL_EOK != alg->fxns->process(alg, &inBufDesc, &outBufDesc,
            &inOutBufDesc, (IUNIVERSAL_InArgs *)&decInArgs, &decOutArgs)) {
            System_abort(" rmanTask> TEST FAILED****** in Task Id " + taskId);
    }

    /*
     * Deactivate All Resources
     */
    RMAN_deactivateAllResources((IALG_Handle)alg, resFxns, scratchId);

    /*
     * Deactivate algorithm
     */
    DSKT2_deactivateAlg(scratchId, (IALG_Handle)alg);

    /*
     * Free resources assigned to this algorihtm
     */
    status = RMAN_freeResources((IALG_Handle)(alg), resFxns, scratchId);
    if (IRES_OK != status) {
        System_printf("Free Resource Failed [%d]\n", status);
        return (-1);
    }

    SemThread_pend(mutex, SemThread_FOREVER, NULL);

    /* Free instance of the algorithm created */
    DSKT2_freeAlg(scratchId, (IALG_Handle)alg);

    SemThread_post(mutex, NULL);

    SemThread_post(done, NULL);

    Log_print1(Diags_USER4, "[+4] rmanTask> Completed task %d", (IArg)taskId);

    return (0);
}

/*
 *  ======== myIdle ========
 *  Idle task can do the cleanup ?
 */
Void myIdle()
{
    IRES_Status status ;

    status = RMAN_exit();

    if (IRES_OK != status) {

        Log_print0(Diags_USER7, "[+7] _myIdle> RMAN Exit Failed ");

        exit(-1);
    }

    exit(0);
}
