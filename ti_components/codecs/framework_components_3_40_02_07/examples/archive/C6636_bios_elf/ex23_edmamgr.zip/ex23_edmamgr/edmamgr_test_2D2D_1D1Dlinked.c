/*
 * (C) Copyright 2013, Texas Instruments Incorporated.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <xdc/std.h>
#include <xdc/runtime/System.h>

#include <string.h>

#include <ti/sysbios/family/c66/Cache.h>
#include <ti/sdo/fc/edmamgr/edmamgr.h>

#include "edmamgr_test.h"

/*******************************************************************************
 * FUNCTION PURPOSE: Test simulataneous 2D2D transfer and 1D1D linked transfer.
 *******************************************************************************
   DESCRIPTION: This function allocates two edmaMgr channels, and
                simultaneously performs a single 2D2D transfer, and a 1D1D
                linked transfer.
 ******************************************************************************/
int32_t EdmaMgr_test_2D2D_1D1Dlinked(int32_t core_id)
{
  EdmaMgr_Handle  edmaMgrHandles[2];

  void* input_ptr=&input[0];
  void* output_ptr=&output[0];
  void* output2_ptr=&output2[0];
  void *input_linked[2], *output_linked[2];
  int  num_bytes = BUF_SIZE, num_bytes_x = BUF_SIZE_X, num_bytes_y = BUF_SIZE_Y, num_bytes_linked[2];
  int  i, ret_val, errors = 0;


  /**
   *   Test: 2 Channels
   *
   *   Channel 1: 2D2D signle transfer
   *   Channel 2: 1D1D linked transfer
   */
  System_printf("EdmaMgr 2D2D + 1D1D,linked Test \n");
  System_printf("Chan 1: 2D2D, 1 link\n");
  System_printf("Chan 2: 1D1D, 2 links\n");

  /* Prepare input data */
  memset(input_ptr, 0xAB, num_bytes);
  Cache_wbInv(input_ptr, num_bytes, Cache_Type_ALL, TRUE);

  /* Clear output data */
  memset(output_ptr, 0, num_bytes);
  Cache_wbInv(output_ptr, num_bytes, Cache_Type_ALL, TRUE);
  memset(output2_ptr, 0, num_bytes);
  Cache_wbInv(output2_ptr, num_bytes, Cache_Type_ALL, TRUE);

  /* Allocate edmaMgr channel for single transfer */
  System_printf("\tAllocating edmaMgr handle...  ");
  edmaMgrHandles[0] = EdmaMgr_alloc(1);
  app_assert( (edmaMgrHandles[0] != NULL), core_id, "Error with EdmaMgr_alloc(1)");
  System_printf("Success!\n");

  /* Trigger single 2D2D transfer */
  System_printf("\tCopy 1: %dx%d bytes...  ", num_bytes_x, num_bytes_y);
  EdmaMgr_copy2D2D(edmaMgrHandles[0], input_ptr, output_ptr, num_bytes_x, num_bytes_y, num_bytes_x);
  System_printf("Done.\n");

  /* Allocate edmaMgr channel for linked transfer */
  System_printf("\tAllocating edmaMgr handle...  ");
  edmaMgrHandles[1] = EdmaMgr_alloc(2);
  app_assert( (edmaMgrHandles[1] != NULL), core_id, "Error with EdmaMgr_alloc(2)");
  System_printf("Success!\n");

  /* Set up first transfer */
  input_linked[0] = input_ptr;
  output_linked[0] = output2_ptr;
  num_bytes_linked[0] = num_bytes / 2;

  /* Set up second, linked, transfer */
  input_linked[1] = (void *)((uint32_t)input_linked[0] + num_bytes_linked[0]);
  output_linked[1] = (void *)((uint32_t)output_linked[0] + num_bytes_linked[0]);
  num_bytes_linked[1] = num_bytes - num_bytes_linked[0];

  /* Trigger linked transfer */
  System_printf("\tCopy 2: %d bytes -> %d bytes...  ", num_bytes_linked[0], num_bytes_linked[1]);
  EdmaMgr_copy1D1DLinked(edmaMgrHandles[1], input_linked, output_linked, num_bytes_linked, 2);
  System_printf("Done.\n");


  /* Wait for single 2D2D transfer */
  System_printf("\tWaiting for transfer 1...  ");
  EdmaMgr_wait(edmaMgrHandles[0]);
  System_printf("Complete!\n");

  /* Wait for linked 1D1D transfer */
  System_printf("\tWaiting for transfer 2...  ");
  EdmaMgr_wait(edmaMgrHandles[1]);
  System_printf("Complete!\n");

  /* Verify output */
  Cache_wbInv(output_ptr, num_bytes, Cache_Type_ALL, TRUE);
  for (i=0; i<num_bytes; i++)
  {
    if(output[i] != input[i])
    {
      System_printf("\tData verification failed for channel 1 (i=%d)!!!!!!!!! \n",i);
      errors++;
      break;
    }
  }

  if (i==num_bytes)
  {
    System_printf("\tData verification passed for channel 1\n");
  }

  /* Verify output */
  Cache_wbInv(&output2[0], num_bytes, Cache_Type_ALL, TRUE);
  for (i=0; i<num_bytes; i++)
  {
    if(output2[i] != input[i])
    {
      System_printf("\tData verification failed for channel 2 (i=%d)!!!!!!!!! \n",i);
      errors++;
      break;
    }
  }

  if (i==num_bytes)
  {
    System_printf("\tData verification passed for channel 2\n");
  }

  /* Free edmaMgr channels */
  System_printf("\tFreeing edmaMgr handle 1...  ");
  ret_val = EdmaMgr_free(edmaMgrHandles[0]);
  app_assert( (ret_val == 0), core_id, "Error in EdmaMgr_free()");
  System_printf("Success!\n");

  System_printf("\tFreeing edmaMgr handle 2...  ");
  ret_val = EdmaMgr_free(edmaMgrHandles[1]);
  app_assert( (ret_val == 0), core_id, "Error in EdmaMgr_free()");
  System_printf("Success!\n");

  System_printf("\nEdmaMgr 2D2D + 1D1D,linked Test: %d errors\n\n", errors);

  return (errors);
}
