#!/bin/sh

set -x

# run host application
app_host
