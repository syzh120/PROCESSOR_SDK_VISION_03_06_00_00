#!/bin/sh

set -x
mpmcl reset dsp0
mpmcl reset dsp1
mpmcl reset dsp2
mpmcl reset dsp3
mpmcl reset dsp4
mpmcl reset dsp5
mpmcl reset dsp6
mpmcl reset dsp7
