#!/bin/sh

set -x
./lad_tci6638 -l log.txt
