/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-x20
 */

#ifndef platform_evmTCI6614_custom__
#define platform_evmTCI6614_custom__



#endif /* platform_evmTCI6614_custom__ */ 
