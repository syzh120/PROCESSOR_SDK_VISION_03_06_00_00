/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-x20
 */

#ifndef platform_simTCI6614_custom__
#define platform_simTCI6614_custom__



#endif /* platform_simTCI6614_custom__ */ 
