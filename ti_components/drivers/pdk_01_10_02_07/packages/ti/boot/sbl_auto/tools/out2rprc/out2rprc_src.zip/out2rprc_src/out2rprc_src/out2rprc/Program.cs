﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace out2rprc
{
    class Program
    {
        static void Main(string[] args)
        {
            String input_file_name_1, /*input_file_name_2,*/ output_file_name;

            // check usage
            if (args.Length == 2)
            {
                // 2 args: 1 input file and 1 output file
                input_file_name_1 = args[0];
                //input_file_name_2 = "";
                output_file_name = args[1];
            }
#if accept_second_file
            else if (args.Length == 3)
            {
                // 3 args: 2 input files and 1 output file
                input_file_name_1 = args[0];
                input_file_name_2 = args[1];
                output_file_name = args[2];
            }
#endif
            else
            {
                // print usage instructions and quit
                Console.WriteLine("out2rprc version number 2.0");
                Console.WriteLine("Usage:");
                Console.WriteLine("out2rprc.exe <input file 1 (COFF or ELF)> <output file (RPRC)>");
                return;
            }

            // convert file to RPRC binary format
            try
            {
                Out2Rprc.Convert(input_file_name_1, /*input_file_name_2, */output_file_name);
                Console.WriteLine("File conversion complete!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Encountered exception:");
                Console.WriteLine(ex.Message);
            }
        }
    }
}
